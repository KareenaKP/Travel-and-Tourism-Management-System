# Travel and Tourism management  using java and mysql
"The Travel and Tourism Management System is a Java-based application designed to streamline and automate various aspects of managing travel and tourism activities. Leveraging the power of Java and MySQL, this system offers a comprehensive solution for travel agencies, tour operators, and travelers alike."

Tech Stack:
java-swing
mysql

Running Tests
To run tests, run the following command

```bash
  add the conn.java file for mysql connection
```
```bash
  then run the project
```
If you have any feedback, please reach out to us at parthasarathipthl@gmail.com
